import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
import joblib

# Load dataset
data = pd.read_csv("hospital data analysis.csv")

# Convert Gender to numeric (Male=0, Female=1)
data["Gender"] = data["Gender"].map({"Male": 0, "Female": 1})

# Select features and target
X = data[["Age", "Gender", "Condition"]]
y = data["Cost"]

# Encode categorical column (Condition)
X = pd.get_dummies(X, columns=["Condition"], drop_first=True)

# Scale numeric columns
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Train a cost prediction model
cost_model = RandomForestRegressor(n_estimators=100, random_state=42)
cost_model.fit(X_scaled, y)

# Save model and scaler
joblib.dump(cost_model, "model/cost_model.pkl")
joblib.dump(scaler, "model/scaler.pkl")

print("✅ Model trained and saved successfully using simplified features (Age, Gender, Condition).")


