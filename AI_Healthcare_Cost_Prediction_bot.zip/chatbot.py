import joblib
import numpy as np
import pandas as pd

# Load model and scaler
cost_model = joblib.load("model/cost_model.pkl")
scaler = joblib.load("model/scaler.pkl")

conversation_state = {"mode": None}


def chatbot_response(user_input):
    user_input = user_input.strip().lower()

    # Greetings
    if user_input in ["hi", "hello", "hey"]:
        return "Hello 👋 I’m your Healthcare Assistant. Type 'predict cost' to begin."

    elif "predict cost" in user_input:
        conversation_state["mode"] = "cost"
        return "Please provide details in this format:\n👉 Age, Gender (Male/Female), Condition"

    elif conversation_state.get("mode") == "cost":
        try:
            parts = [x.strip() for x in user_input.split(",")]
            if len(parts) < 3:
                return "⚠️ Please enter all 3 details: Age, Gender (Male/Female), Condition."

            age = float(parts[0])
            gender = parts[1].lower()
            gender_val = 1 if gender == "female" else 0
            condition = parts[2]

            df = pd.DataFrame([{
                "Age": age,
                "Gender": gender_val,
                "Condition": condition
            }])

            df_encoded = pd.get_dummies(df, drop_first=True).reindex(columns=scaler.feature_names_in_, fill_value=0)
            scaled_features = scaler.transform(df_encoded)

            predicted_cost = cost_model.predict(scaled_features)[0]
            conversation_state["mode"] = None

            return f"💰 The estimated hospital cost is approximately ₹{predicted_cost:,.2f}."

        except Exception as e:
            return "⚠️ Invalid input. Please use this format:\n👉 45, Male, Diabetes"

    else:
        return "I can help you predict hospital costs. Type 'predict cost' to start."


